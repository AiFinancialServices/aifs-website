# Ai Financial Services Website

Static landing page for **aifinancialservicesinc.com**.

## Deploy on Vercel

1. Create a new repo on GitHub (e.g., `aifs-website`) and upload these files.
2. In Vercel, import the repo → New Project.
3. Add `aifinancialservicesinc.com` in Project → Domains.
4. Update DNS at Squarespace as Vercel instructs.
